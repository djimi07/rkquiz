const account = (pay) => {

    return {

        type: 'infos',
        bool: pay
    }
}

export default account;