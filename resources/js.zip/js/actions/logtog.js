 const logtog = (pay) => {

    return {

        type: 'login',
        bool: pay
    }
}

export default logtog;